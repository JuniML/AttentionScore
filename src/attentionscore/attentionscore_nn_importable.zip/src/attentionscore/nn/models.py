from __future__ import annotations

import math
import torch
from torch import nn

drop_out_rating: float = 0.001

class MultiHeadAttention(nn.Module):
    def __init__(self, input_dim: int, n_heads: int, output_dim: int | None = None):
        super().__init__()
        assert n_heads >= 1, "n_heads must be >= 1"
        assert input_dim % n_heads == 0, "input_dim must be divisible by n_heads"
        self.n_heads = n_heads
        self.d_k = self.d_v = input_dim // n_heads
        self.output_dim = input_dim if output_dim is None else output_dim

        self.W_Q = nn.Linear(input_dim, self.d_k * n_heads, bias=False)
        self.W_K = nn.Linear(input_dim, self.d_k * n_heads, bias=False)
        self.W_V = nn.Linear(input_dim, self.d_v * n_heads, bias=False)
        self.fc  = nn.Linear(n_heads * self.d_v, self.output_dim, bias=False)

    def forward(self, X: torch.Tensor) -> torch.Tensor:
        Q = self.W_Q(X).view(-1, self.n_heads, self.d_k).transpose(0, 1)
        K = self.W_K(X).view(-1, self.n_heads, self.d_k).transpose(0, 1)
        V = self.W_V(X).view(-1, self.n_heads, self.d_v).transpose(0, 1)

        scores = torch.matmul(Q, K.transpose(-1, -2)) / math.sqrt(self.d_k)
        attn = torch.softmax(scores, dim=-1)
        context = torch.matmul(attn, V)

        context = context.transpose(1, 2).reshape(-1, self.n_heads * self.d_v)
        output = self.fc(context)
        return output


class EncoderLayer(nn.Module):
    def __init__(self, input_dim: int, n_heads: int):
        super().__init__()
        self.attn = MultiHeadAttention(input_dim, n_heads)
        self.AN1  = nn.LayerNorm(input_dim)
        self.l1   = nn.Linear(input_dim, input_dim)
        self.AN2  = nn.LayerNorm(input_dim)

    def forward(self, X: torch.Tensor) -> torch.Tensor:
        out = self.attn(X)
        X   = self.AN1(out + X)
        out = self.l1(X)
        X   = self.AN2(out + X)
        return X


def gelu(x: torch.Tensor) -> torch.Tensor:
    return x * 0.5 * (1.0 + torch.erf(x / math.sqrt(2.0)))


class feature_encoder(nn.Module):
    def __init__(self, vector_size: int, n_heads: int, n_layers: int):
        super().__init__()
        self.layers = nn.ModuleList([EncoderLayer(vector_size, n_heads) for _ in range(n_layers)])
        self.AN = nn.LayerNorm(vector_size)

        self.l1 = nn.Linear(vector_size, vector_size // 2)
        self.bn1 = nn.BatchNorm1d(vector_size // 2)

        self.l2 = nn.Linear(vector_size // 2, vector_size // 4)

        self.l3 = nn.Linear(vector_size // 4, vector_size // 2)
        self.bn3 = nn.BatchNorm1d(vector_size // 2)

        self.l4 = nn.Linear(vector_size // 2, vector_size)

        self.dr = nn.Dropout(drop_out_rating)
        self.ac = gelu

    def forward(self, X: torch.Tensor):
        for layer in self.layers:
            X = layer(X)
        X1 = self.AN(X)
        X2 = self.dr(self.bn1(self.ac(self.l1(X1))))
        X3 = self.l2(X2)
        X4 = self.dr(self.bn3(self.ac(self.l3(self.ac(X3)))))
        X5 = self.l4(X4)
        return X1, X2, X3, X5


class feature_encoder2(nn.Module):
    def __init__(self, vector_size: int):
        super().__init__()
        self.l1 = nn.Linear(vector_size, vector_size // 2)
        self.bn1 = nn.BatchNorm1d(vector_size // 2)
        self.l2 = nn.Linear(vector_size // 2, vector_size // 4)
        self.bn2 = nn.BatchNorm1d(vector_size // 4)
        self.dr = nn.Dropout(drop_out_rating)
        self.ac = gelu

    def forward(self, X: torch.Tensor):
        X = self.dr(self.bn1(self.ac(self.l1(X))))
        X = self.dr(self.bn2(self.ac(self.l2(X))))
        return X


class Model(nn.Module):
    def __init__(self, input_dim_A: int, input_dim_B: int, n_heads: int, n_layers: int, event_num: int = 1):
        super().__init__()
        self.input_dim_A = input_dim_A
        self.input_dim_B = input_dim_B
        self.drugEncoderA = feature_encoder(input_dim_A, n_heads, n_layers)
        self.drugEncoderB = feature_encoder(input_dim_B, n_heads, n_layers)

        self.feaEncoder1_3_input_dim = input_dim_A + input_dim_B // 4
        self.feaEncoder3_1_input_dim = input_dim_B + input_dim_A // 4
        self.feaEncoder2_input_dim   = input_dim_A // 2 + input_dim_B // 2

        self.feaEncoder1 = feature_encoder2(self.feaEncoder1_3_input_dim)
        self.feaEncoder2 = feature_encoder2(self.feaEncoder2_input_dim)
        self.feaEncoder3 = feature_encoder2(self.feaEncoder3_1_input_dim)

        fe1_out = self.feaEncoder1_3_input_dim // 4
        fe3_out = self.feaEncoder3_1_input_dim // 4
        fe2_out = self.feaEncoder2_input_dim // 4

        self.feaFui_input_dim = fe1_out + fe3_out + fe2_out + input_dim_A // 4 + input_dim_B // 4
        self.feaFui = feature_encoder2(self.feaFui_input_dim)

        self.linear_input_dim = self.feaFui_input_dim // 4 + self.feaFui_input_dim

        self.l1 = nn.Linear(self.linear_input_dim, self.linear_input_dim // 2)
        self.bn1 = nn.BatchNorm1d(self.linear_input_dim // 2)
        self.l2 = nn.Linear(self.linear_input_dim // 2, 1)

        self.ac = gelu
        self.dr = nn.Dropout(drop_out_rating)
        self.sigmoid = nn.Sigmoid()

    def forward(self, XA: torch.Tensor, XB: torch.Tensor):
        XA1, XA2, XA3, XAC = self.drugEncoderA(XA)
        XB1, XB2, XB3, XBC = self.drugEncoderB(XB)

        XDC = torch.cat((XAC, XBC), 1)

        X1 = torch.cat((XA1, XB3), 1)
        X2 = torch.cat((XA2, XB2), 1)
        X3 = torch.cat((XA3, XB1), 1)

        X1 = self.feaEncoder1(X1)
        X2 = self.feaEncoder2(X2)
        X3 = self.feaEncoder3(X3)

        XC = torch.cat((X1, X2, X3, XA3, XB3), 1)
        XC = self.feaFui(XC)

        X = torch.cat((XA3, XB3, X1, X2, X3, XC), 1)
        X = self.dr(self.bn1(self.ac(self.l1(X))))
        X = self.l2(X)
        X = self.sigmoid(X)
        return X, XC, XDC, XAC, XBC