# attentionscore.nn — Dual-branch Attention Model (Reusable)
See `src/attentionscore/nn/` for models, data utils, and deterministic K-fold training.